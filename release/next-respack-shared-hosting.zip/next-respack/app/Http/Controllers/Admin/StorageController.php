<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ResourcePackVersion;
use App\Models\StorageMigration;
use App\Models\SystemSetting;
use App\Services\Security\AuditLogger;
use App\Services\Storage\StorageManager;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\View\View;
use Throwable;

class StorageController extends Controller
{
    public function index(StorageManager $storage, AuditLogger $audit): View
    {
        $driver = $storage->currentDriver();
        $usage = [
            'files' => ResourcePackVersion::query()->count(),
            'bytes' => (int) ResourcePackVersion::query()->sum('file_size'),
            'local_bytes' => (int) ResourcePackVersion::query()->where('storage_driver', 'local')->sum('file_size'),
            's3_bytes' => (int) ResourcePackVersion::query()->where('storage_driver', 's3')->sum('file_size'),
            'webdav_bytes' => (int) ResourcePackVersion::query()->where('storage_driver', 'webdav')->sum('file_size'),
        ];

        $localFree = null;
        if ($driver === 'local') {
            try {
                $localFree = @disk_free_space($storage->localPath());
            } catch (Throwable) {
            }
        }

        $migrations = StorageMigration::query()->latest()->limit(10)->get();
        $settings = [
            'driver' => $driver,
            'local_path' => $storage->localPath(),
            's3_endpoint' => nr_setting('s3_endpoint', ''),
            's3_region' => nr_setting('s3_region', 'us-east-1'),
            's3_bucket' => nr_setting('s3_bucket', ''),
            's3_access_key' => nr_setting('s3_access_key', ''),
            's3_path_style' => nr_setting_bool('s3_path_style', true),
            's3_prefix' => nr_setting('s3_prefix', ''),
            'secret_set' => nr_setting('s3_secret_key', '') !== '',
            'webdav_url' => nr_setting('webdav_url', ''),
            'webdav_username' => nr_setting('webdav_username', ''),
            'webdav_prefix' => nr_setting('webdav_prefix', ''),
            'webdav_root' => nr_setting('webdav_root', ''),
            'webdav_verify_ssl' => nr_setting_bool('webdav_verify_ssl', true),
            'webdav_connect_timeout' => nr_setting_int('webdav_connect_timeout', 15),
            'webdav_timeout' => nr_setting_int('webdav_timeout', 120),
            'webdav_password_set' => nr_setting('webdav_password', '') !== '',
        ];

        return view('admin.storage.index', compact('driver', 'usage', 'localFree', 'migrations', 'settings'));
    }

    public function test(Request $request, StorageManager $storage): JsonResponse
    {
        $driver = (string) $request->input('target_driver', $storage->currentDriver());

        if ($driver === 's3') {
            $config = [
                'driver' => 's3',
                'endpoint' => (string) $request->input('s3_endpoint', ''),
                'region' => (string) $request->input('s3_region', 'us-east-1'),
                'bucket' => (string) $request->input('s3_bucket', ''),
                'access_key' => (string) $request->input('s3_access_key', ''),
                'secret_key' => (string) $request->input('s3_secret_key', ''),
                'path_style' => (bool) $request->input('s3_path_style', true),
                'prefix' => (string) $request->input('s3_prefix', ''),
            ];

            if ($config['secret_key'] === '' && nr_setting('s3_secret_key', '') !== '') {
                $config['secret_key'] = $storage->decryptSecret(nr_setting('s3_secret_key', ''));
            }
        } elseif ($driver === 'webdav') {
            $config = [
                'driver' => 'webdav',
                'url' => (string) $request->input('webdav_url', ''),
                'username' => (string) $request->input('webdav_username', ''),
                'password' => (string) $request->input('webdav_password', ''),
                'prefix' => (string) $request->input('webdav_prefix', ''),
                'root' => (string) $request->input('webdav_root', ''),
                'verify_ssl' => (bool) $request->input('webdav_verify_ssl', true),
                'connect_timeout' => (int) $request->input('webdav_connect_timeout', 15),
                'timeout' => (int) $request->input('webdav_timeout', 120),
            ];

            if ($config['password'] === '' && nr_setting('webdav_password', '') !== '') {
                $config['password'] = $storage->decryptSecret(nr_setting('webdav_password', ''));
            }
        } else {
            $config = ['driver' => 'local', 'path' => (string) $request->input('local_path', $storage->localPath())];
        }

        $result = $storage->test($driver, $config);

        return response()->json($result, $result['ok'] ? 200 : 422);
    }

    public function plan(Request $request, StorageManager $storage, AuditLogger $audit): RedirectResponse
    {
        $data = $request->validate([
            'target_driver' => ['required', 'in:local,s3,webdav'],
            'local_path' => ['nullable', 'string', 'max:255'],
            's3_endpoint' => ['nullable', 'url', 'max:191'],
            's3_region' => ['nullable', 'string', 'max:64'],
            's3_bucket' => ['nullable', 'string', 'max:191'],
            's3_access_key' => ['nullable', 'string', 'max:191'],
            's3_secret_key' => ['nullable', 'string', 'max:191'],
            's3_prefix' => ['nullable', 'string', 'max:191'],
            'webdav_url' => ['nullable', 'url', 'max:191'],
            'webdav_username' => ['nullable', 'string', 'max:191'],
            'webdav_password' => ['nullable', 'string', 'max:191'],
            'webdav_prefix' => ['nullable', 'string', 'max:191'],
            'webdav_root' => ['nullable', 'string', 'max:191'],
            'webdav_verify_ssl' => ['nullable', 'boolean'],
            'webdav_connect_timeout' => ['nullable', 'integer', 'min:1', 'max:120'],
            'webdav_timeout' => ['nullable', 'integer', 'min:1', 'max:600'],
        ]);

        $target = $data['target_driver'];
        $config = $this->targetConfig($data);

        if ($target === 's3' && empty($data['s3_bucket'])) {
            return back()->withErrors(['s3_bucket' => __('An S3 bucket is required.')]);
        }

        if ($target === 'webdav' && empty($data['webdav_url'])) {
            return back()->withErrors(['webdav_url' => __('A WebDAV URL is required.')]);
        }

        if ($this->targetIsActive($target, $config, $storage)) {
            return back()->withErrors(['target_driver' => __('The target backend is already active.')]);
        }

        if ($target === 's3' && empty($data['s3_secret_key']) && nr_setting('s3_secret_key', '') !== '') {
            $config['secret_key'] = $storage->decryptSecret(nr_setting('s3_secret_key', ''));
        }

        if ($target === 'webdav' && empty($data['webdav_password']) && nr_setting('webdav_password', '') !== '') {
            $config['password'] = $storage->decryptSecret(nr_setting('webdav_password', ''));
        }

        $result = $storage->test($target, $config);
        if (! $result['ok']) {
            return back()->withInput()->withErrors(['storage' => implode(' ', $result['errors'])]);
        }

        $stats = $config;
        if (isset($stats['secret_key'])) {
            $stats['secret_key'] = $storage->encryptSecret((string) $stats['secret_key']);
        }
        if (isset($stats['password'])) {
            $stats['password'] = $storage->encryptSecret((string) $stats['password']);
        }
        $stats['files'] = ResourcePackVersion::query()->count();
        $stats['bytes'] = (int) ResourcePackVersion::query()->sum('file_size');

        $migration = StorageMigration::create([
            'from_driver' => $storage->currentDriver(),
            'to_driver' => $target,
            'status' => 'planned',
            'stats' => $stats,
        ]);

        $audit->log('admin.storage_migration_planned', $migration, __('Storage migration plan created.'), ['to' => $target]);

        return redirect()->route('admin.storage.index')->with('status', __('Migration plan created. Existing download links still use the old backend until you run the migration.'));
    }

    public function run(StorageMigration $migration, StorageManager $storage, AuditLogger $audit): RedirectResponse
    {
        if ($migration->status === 'running' || $migration->status === 'completed') {
            return back()->withErrors(['migration' => __('This migration cannot be run again.')]);
        }

        $stats = $migration->stats ?? [];
        $config = $stats;
        if (isset($config['secret_key'])) {
            $config['secret_key'] = $storage->decryptSecret((string) $config['secret_key']);
        }
        if (isset($config['password'])) {
            $config['password'] = $storage->decryptSecret((string) $config['password']);
        }

        if ($this->targetIsActive($migration->to_driver, $config, $storage)) {
            return back()->withErrors(['migration' => __('The target backend is already active.')]);
        }

        @set_time_limit(0);

        $migration->update(['status' => 'running', 'started_at' => now(), 'error' => null]);

        $targetDriver = $migration->to_driver;
        $target = $storage->adapter($targetDriver, $config);
        $copied = 0;
        $bytes = 0;
        $versions = ResourcePackVersion::query()->get();

        try {
            foreach ($versions as $version) {
                $source = $storage->adapter($version->storage_driver);
                if (! $source->exists($version->storage_path)) {
                    throw new \RuntimeException(__('Source file is missing for version #:id.', ['id' => $version->id]));
                }

                if (! $target->exists($version->storage_path)) {
                    $stream = $source->readStream($version->storage_path);
                    try {
                        $target->putStream($version->storage_path, $stream);
                    } finally {
                        if (is_resource($stream)) {
                            fclose($stream);
                        }
                    }
                }

                $targetSize = $target->size($version->storage_path);
                if ($targetSize !== (int) $version->file_size) {
                    throw new \RuntimeException(__('Size verification failed for version #:id.', ['id' => $version->id]));
                }

                $targetHash = $target->hash('sha1', $version->storage_path);
                if ($targetHash !== $version->sha1) {
                    throw new \RuntimeException(__('SHA-1 verification failed for version #:id.', ['id' => $version->id]));
                }

                $copied++;
                $bytes += (int) $version->file_size;
            }

            DB::transaction(function () use ($versions, $targetDriver, $stats, $migration) {
                foreach ($versions as $version) {
                    $version->storage_driver = $targetDriver;
                    $version->save();
                }

                $this->applyTargetSettings($stats);
                $migration->update([
                    'status' => 'completed',
                    'finished_at' => now(),
                    'stats' => array_merge($migration->stats ?? [], [
                        'copied_files' => $versions->count(),
                        'copied_bytes' => (int) $versions->sum('file_size'),
                    ]),
                ]);
            });

            $audit->log('admin.storage_migration_completed', $migration, __('Storage migration completed.'), ['files' => $copied, 'bytes' => $bytes]);

            return redirect()->route('admin.storage.index')->with('status', __('Storage migration completed. :files files copied and verified.', ['files' => $copied]));
        } catch (Throwable $e) {
            $migration->update([
                'status' => 'failed',
                'finished_at' => now(),
                'error' => $e->getMessage(),
                'stats' => array_merge($stats, ['copied_files' => $copied, 'copied_bytes' => $bytes]),
            ]);
            Log::warning('Storage migration failed: '.$e->getMessage());

            return back()->withErrors(['migration' => __('Migration failed: :message', ['message' => $e->getMessage()])]);
        }
    }

    public function cleanOrphans(StorageManager $storage, AuditLogger $audit): RedirectResponse
    {
        if ($storage->currentDriver() !== 'local') {
            return back()->withErrors(['storage' => __('Orphan cleanup is currently implemented for local storage only.')]);
        }

        $root = $storage->localPath();
        if (! is_dir($root)) {
            return back()->withErrors(['storage' => __('The local storage directory does not exist.')]);
        }

        $known = ResourcePackVersion::query()->where('storage_driver', 'local')->pluck('storage_path')->all();
        $known = array_flip($known);
        $deleted = 0;
        $bytes = 0;

        $iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $file) {
            if (! $file->isFile()) {
                continue;
            }
            $relative = ltrim(str_replace($root, '', $file->getPathname()), '/');
            if (in_array($relative, ['.htaccess', 'index.html'], true) || str_contains($relative, '.part-')) {
                continue;
            }
            if (! isset($known[$relative])) {
                $bytes += $file->getSize();
                @unlink($file->getPathname());
                $deleted++;
            }
        }

        $audit->log('admin.orphan_files_cleaned', null, __('Orphan storage files cleaned.'), ['files' => $deleted, 'bytes' => $bytes]);

        return back()->with('status', __('Orphan cleanup complete: :files files (:bytes) removed.', ['files' => $deleted, 'bytes' => nr_bytes($bytes)]));
    }

    private function targetConfig(array $data): array
    {
        if ($data['target_driver'] === 's3') {
            return [
                'driver' => 's3',
                'endpoint' => $data['s3_endpoint'] ?? '',
                'region' => $data['s3_region'] ?? 'us-east-1',
                'bucket' => $data['s3_bucket'] ?? '',
                'access_key' => $data['s3_access_key'] ?? '',
                'secret_key' => $data['s3_secret_key'] ?? '',
                'path_style' => (bool) ($data['s3_path_style'] ?? true),
                'prefix' => $data['s3_prefix'] ?? '',
            ];
        }

        if ($data['target_driver'] === 'webdav') {
            return [
                'driver' => 'webdav',
                'url' => $data['webdav_url'] ?? '',
                'username' => $data['webdav_username'] ?? '',
                'password' => $data['webdav_password'] ?? '',
                'prefix' => $data['webdav_prefix'] ?? '',
                'root' => $data['webdav_root'] ?? '',
                'verify_ssl' => (bool) ($data['webdav_verify_ssl'] ?? true),
                'connect_timeout' => (int) ($data['webdav_connect_timeout'] ?? 15),
                'timeout' => (int) ($data['webdav_timeout'] ?? 120),
            ];
        }

        return ['driver' => 'local', 'path' => $data['local_path'] ?: config('nextrespack.storage_root')];
    }

    private function targetIsActive(string $driver, array $config, StorageManager $storage): bool
    {
        if ($driver === 'local') {
            try {
                $target = $storage->resolveLocalPath((string) ($config['path'] ?? config('nextrespack.storage_root')));
            } catch (Throwable) {
                return false;
            }

            return $target === $storage->localPath();
        }

        if ($driver !== $storage->currentDriver()) {
            return false;
        }

        if ($driver === 'webdav') {
            return rtrim((string) ($config['url'] ?? ''), '/') === rtrim((string) nr_setting('webdav_url', ''), '/')
                && (string) ($config['prefix'] ?? '') === (string) nr_setting('webdav_prefix', '')
                && (string) ($config['root'] ?? '') === (string) nr_setting('webdav_root', '');
        }

        return (string) ($config['bucket'] ?? '') === (string) nr_setting('s3_bucket', '')
            && (string) ($config['prefix'] ?? '') === (string) nr_setting('s3_prefix', '')
            && (string) ($config['endpoint'] ?? '') === (string) nr_setting('s3_endpoint', '');
    }

    private function applyTargetSettings(array $stats): void
    {
        SystemSetting::set('storage_driver', $stats['driver'], 'storage');

        if ($stats['driver'] === 's3') {
            SystemSetting::set('s3_endpoint', $stats['endpoint'] ?? '', 'storage');
            SystemSetting::set('s3_region', $stats['region'] ?? 'us-east-1', 'storage');
            SystemSetting::set('s3_bucket', $stats['bucket'] ?? '', 'storage');
            SystemSetting::set('s3_access_key', $stats['access_key'] ?? '', 'storage');
            SystemSetting::set('s3_secret_key', $stats['secret_key'] ?? '', 'storage');
            SystemSetting::set('s3_path_style', ! empty($stats['path_style']), 'storage', 'bool');
            SystemSetting::set('s3_prefix', $stats['prefix'] ?? '', 'storage');
        } elseif ($stats['driver'] === 'webdav') {
            SystemSetting::set('webdav_url', $stats['url'] ?? '', 'storage');
            SystemSetting::set('webdav_username', $stats['username'] ?? '', 'storage');
            SystemSetting::set('webdav_password', $stats['password'] ?? '', 'storage');
            SystemSetting::set('webdav_prefix', $stats['prefix'] ?? '', 'storage');
            SystemSetting::set('webdav_root', $stats['root'] ?? '', 'storage');
            SystemSetting::set('webdav_verify_ssl', ! empty($stats['verify_ssl']), 'storage', 'bool');
            SystemSetting::set('webdav_connect_timeout', max(1, (int) ($stats['connect_timeout'] ?? 15)), 'storage', 'int');
            SystemSetting::set('webdav_timeout', max(1, (int) ($stats['timeout'] ?? 120)), 'storage', 'int');
        } else {
            SystemSetting::set('storage_local_path', $stats['path'] ?? config('nextrespack.storage_root'), 'storage');
        }

        SystemSetting::forgetCache();
    }
}
